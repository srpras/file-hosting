﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleClassLibrary
{
    public class CustomerService
    {
        private readonly ICustomerRepository _repository;
        
        public CustomerService(ICustomerRepository repository) 
        {
            _repository = repository;
        }

        public int SaveCustomer(Customer customer)
        {
            if (customer == null)
                throw new ArgumentNullException("Customer cannot be null");

            if (string.IsNullOrWhiteSpace(customer.Name))
                throw new InvalidDataException("Name cannot be empty");

            if (string.IsNullOrWhiteSpace(customer.Email))
                throw new InvalidDataException("Email cannot be empty");

            if (customer.Id == 0 && _repository.Search(customer.Email) != null)
                throw new InvalidOperationException("Customer already exists");

            if (customer.Id == 0)
                return _repository.Add(customer);
            else
                return _repository.Update(customer);
        }
    }
}
