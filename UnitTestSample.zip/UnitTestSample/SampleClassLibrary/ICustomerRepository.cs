﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleClassLibrary
{
    public interface ICustomerRepository
    {
        int Add(Customer customer);
        int Update(Customer customer);
        void Delete(int id);
        Customer? Get(int id);
        Customer? Search(string email);
    }
}
