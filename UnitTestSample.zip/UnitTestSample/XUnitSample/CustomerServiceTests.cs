using Moq;
using SampleClassLibrary;

namespace XUnitSample
{
    public class CustomerServiceTests
    {
        private Mock<ICustomerRepository> _repository;
        public CustomerServiceTests()
        {
            _repository = new Mock<ICustomerRepository>();
        }

        [Fact]
        public void SaveCustomer_ShouldThrowException_WhenCustomerIsNull()
        {
            // Arrange
            Customer customer = null;
            var service = new CustomerService(_repository.Object);

            // Act
            var act = () => { service.SaveCustomer(customer); };


            // Assert
            Assert.Throws<ArgumentNullException>(act);
        }
    }
}