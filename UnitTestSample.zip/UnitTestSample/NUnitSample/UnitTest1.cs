namespace NUnitSample
{
    [TestFixture]
    public class Tests
    {
        public Tests()
        {

        }

        [SetUp]
        public void Setup()
        {
        }

        [TearDown]
        public void TearDown()
        {

        }

        [OneTimeSetUp]
        public void OneTimeSetup()
        {
        }

        [OneTimeTearDown]
        public void OneTimeTearDown()
        {

        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

        [TestCase(1, 1)]
        [TestCase(1, 2)]
        [TestCase(1, 3)]
        public void Test1(int i, int j)
        {
            Assert.AreEqual(i, j);

            Assert.Throws<DivideByZeroException>(() => throw new DivideByZeroException(), "Exception thrown");
        }
    }
}